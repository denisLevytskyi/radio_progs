DSD+ TCP - A SDR# Plug-in
=========================

 Original by Vasili (TSSDR) modified and updated by thewraith2008 (in 2022)

Description
===========
This plug-in for DSD+ public release v1.101 ONLY
This plug-in for DSD+ public release v1.101 ONLY
This plug-in for DSD+ public release v1.101 ONLY
This plug-in for DSD+ public release v1.101 ONLY
- The TCP output from this plug-in is not compatible with fastlane releases of DSD+.

You can configure DSD+ and run it from plug-in and the SDR# demodulator output is send via TCP to DSD+.


Installation
============
see 'MagicLine.txt'

Usage
=====
Set 'DSDPlus.exe' file location via 'Configure'.
Configure DSD+ via 'Configure'.
- Set output audio device DSD+ will use for decoded audio.
- Set Whatever else

Play SDR#.
Tune to support digital signal for DSD+ to decode.
Click Start DSD.


Click 'Mute this frequency' will mute the digital signal from SDR# for the currently tuned frequency.

Click 'Always mute' so you don't hear the digital signal from SDR# on any frequency tuned too.
- Maybe useful when using with a scanner.

NOTES:
This plug-in for DSD+ public release v1.101 ONLY.

Preferred SDR# version to use is v1716.
While it may work with later versions of SDR#, the smaller buffer it uses may cause TCP streaming issues in some cases.

The 'MP3' option for 'Create per call [WAV|MP3]' cannot be used as it's reported by DSDPlus v1.101 (Public) as 'NOT YET SUPPORTED'.
- Setting this 'MP3' option would cause DSDPlus not to start.

This plug-in has NOT been fully tested and may have bugs and be 'rough around the edges'.
It is supplied as is.
